#!/usr/bin/python

# fleet-indexing_api_call.py


import argparse
import boto3
import json
import random
import time

c_iot = boto3.client('iot')
c_iot_data = boto3.client('iot-data')

#
# aws iot search-index --index-name "AWS_Things" --query-string "connectivity.connected:true"
#
index_name = "AWS_Things"
query_string = "connectivity.connected:true"
# print("query_string: {}".format(query_string))
response = c_iot.search_index(
    indexName=index_name,
    queryString=query_string
)

count = len(response['things'])
print('-'*50)
print('Connected Devices :',count)
for k in range(count):
    response_device = response['things'][k]['thingName']
    print('connected device','[',k,'] :',response_device)

print('-'*50)
print("response:\n{}".format(response))

# room_number = 100

# def shadow_doc():
#     temp = random.randint(15,30)
#     return {
#     "state": {
#         "reported" : {
#             "temperature" : temp
#         }
#     }
# }

# for thing in response["things"]:
#     thing_name = thing["thingName"]
#     shadow_document = json.dumps(shadow_doc(), indent=4)
#     print("updating shadow for thing name: {}".format(thing_name))
#     print("shadow document: {}".format(shadow_document))
#     response2 = c_iot_data.update_thing_shadow(
#         thingName=thing_name,
#         payload=shadow_document
#     )
#     print(response2)
#     print("adding room number {} to thing attributes".format(room_number))
#     response3 = c_iot.update_thing(
#         thingName=thing_name,
#         attributePayload={
#             'attributes': {
#                 'room_number': str(room_number)
#             },
#             'merge': True
#         },
#         removeThingType=False
#     )
#     print(response3)
#     room_number += 1

#     time.sleep(0.5)

# aws iot update-indexing-configuration \
# --thing-indexing-configuration thingIndexingMode=REGISTRY_AND_SHADOW, \
# thingConnectivityIndexingMode=STATUS
response = c_iot.update_indexing_configuration(
    thingIndexingConfiguration={
        'thingIndexingMode': 'REGISTRY_AND_SHADOW',
        'thingConnectivityIndexingMode': 'STATUS',
    }
)